%%AhmadKMahfoud
%%20.01323-0

%% Boas Práticas 
clear;
close all;
clc;
%% Importação de bibliotecas
pkg load signal
pkg load io

%% Lendo áudio da vogal 
file_path = 'audio.wav';
[Y, FS] = audioread(file_path);

% Utilização de vetor tempo
TS = 1 / FS;             
y_len = length(Y);           
final_value = (y_len - 1) * TS; 
time = linspace(0, final_value, y_len);
T0 = 1.1;
t1 = (T0 + 0.1) * FS;
t0 = T0 * FS;
Y = Y(t0:t1);
time = time(t0:t1);
y_len = length(Y);

%% Calculando a Série de Fourier
freq_window = linspace(-FS/2, FS/2, y_len);
FY = abs(fftshift(fft(Y)));
derivative = idivide(length(FY), int16(2)):length(FY);
FY = FY(derivative);
freq = freq_window(derivative);

%Encontrando as frequencias
[_, peaks] = findpeaks(FY(FY>0),'MinPeakDistance', 50); 
f0 = freq(peaks(1))
f1 = freq(peaks(2))
f2 = freq(peaks(3))

%f0 neste caso como ordem e não f0 o qual trata a distancia entre os picos

%% Colocar os valores f1 e f2 no código feito em python no arquivo ZIP